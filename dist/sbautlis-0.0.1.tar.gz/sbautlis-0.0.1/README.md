# sba_utils

Utits Function of Statsbomb Data Analysis

# build the package 

`python3 -m pip install --upgrade build`
`python3 -m build`
`git+file:///Users/typewind/git_projects/Football_Analysis/sba_utils/@master`